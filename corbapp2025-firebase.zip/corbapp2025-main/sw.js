// sw.js — cache offline (PWA) + notifiche push in background (Firebase Cloud Messaging)
const CACHE = "corb-cache-v6"; // <- bumpa quando fai modifiche

const ASSETS = [
  "./",
  "./index.html","./news.html","./squadra.html","./video.html",
  "./prossima.html","./partite.html","./calendario.html","./admin.html",
  "./settings.html",
  "./style.css?v=34",
  "./data-store.js",
  "./firebase-init.js",
  "./ui.js",
  "./install-prompt.js",
  "./manifest.json",
  "./img/logo_c5.png","./img/logo_avv.png","./img/player1.png",
];

self.addEventListener("install", e=>{
  e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)));
  self.skipWaiting();
});
self.addEventListener("activate", e=>{
  e.waitUntil(
    caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))
  );
  self.clients.claim();
});
self.addEventListener("fetch", e=>{
  const {request} = e;
  if (request.method!=="GET") return;
  // Non mettere in cache le chiamate a Firestore/Firebase: devono sempre andare in rete.
  if (request.url.includes('firestore.googleapis.com') || request.url.includes('googleapis.com')) return;
  e.respondWith(
    caches.match(request).then(res=> res || fetch(request).then(net=>{
      const clone = net.clone();
      caches.open(CACHE).then(c=>c.put(request, clone));
      return net;
    }).catch(()=>res))
  );
});

// ---- Notifiche push (Firebase Cloud Messaging) ----
// Il service worker gira "fuori" dalla pagina, quindi non può usare gli import
// ES modules del resto dell'app: usiamo la build "compat" di Firebase via importScripts,
// che è pensata apposta per questo caso.
importScripts("https://www.gstatic.com/firebasejs/10.13.0/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/10.13.0/firebase-messaging-compat.js");

firebase.initializeApp({
  apiKey: "AIzaSyAFmaHbXMTlfTTp6wWVSU76o0_JXrovPeI",
  authDomain: "corb-app26.firebaseapp.com",
  projectId: "corb-app26",
  storageBucket: "corb-app26.firebasestorage.app",
  messagingSenderId: "685810855713",
  appId: "1:685810855713:web:2625310ab8c90af293d860"
});

const messaging = firebase.messaging();

// Notifica ricevuta mentre l'app NON è in primo piano (anche chiusa).
messaging.onBackgroundMessage((payload) => {
  const title = payload?.notification?.title || 'CORB';
  const body  = payload?.notification?.body  || '';
  const url   = payload?.data?.url || './prossima.html';
  self.registration.showNotification(title, {
    body,
    icon: './img/logo_c5.png',
    badge: './img/logo_c5.png',
    data: { url }
  });
});

// Pulsante "Invia notifica di prova" nelle Impostazioni: mostra una notifica
// locale, giusto per verificare che permesso + service worker funzionino.
self.addEventListener('message', (event) => {
  if (event?.data?.type === 'local-test-notify'){
    self.registration.showNotification('CORB • Test', {
      body: 'Questa è una notifica di prova.',
      icon: './img/logo_c5.png',
      data: { url: './index.html' }
    });
  }
});

// Click sulla notifica → apre/porta in primo piano l'app sulla pagina giusta.
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = event.notification?.data?.url || './index.html';
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientsArr) => {
      const existing = clientsArr.find(c => c.url.includes(url.replace('./','')));
      if (existing) return existing.focus();
      return self.clients.openWindow(url);
    })
  );
});
